#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL.h>

int main( int argc, char* args[] )
{
    //Start SDL
    SDL_Init( SDL_INIT_EVERYTHING );
    
    printf("Hello!!!\n");
    
    //Quit SDL
    SDL_Quit();
    
    return 0;    
}